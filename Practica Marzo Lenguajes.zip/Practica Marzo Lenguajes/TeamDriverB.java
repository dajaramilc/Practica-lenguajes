public class TeamDriverB extends F1Team {
    String name;
    int yearf;
    int trophies;
    int numberMembers = 5;

    public TeamDriverB(String name, int yearf, int trophies, int numberMembers){
        super(name, yearf, trophies);
        this.numberMembers = numberMembers;
    }
    public int getNumberMembers() {
        return numberMembers;
    }
    public void setNumberMembers(int numberMembers){
        this.numberMembers = numberMembers;
    }
    private void realizarAccionTeamDriverB() {
        System.out.println("Esta acción fue realizada por el integrante del equipo TeamDriverB: " + getName());
    }
    
    public void realizarOperacion() {
        System.out.println("Realizando operación...");
      
        realizarAccionTeamDriverB();
    }
    
}
