public class NeumaticosEquipo extends PitCrewTeam {

    private int cantidadNeumaticos;
    private boolean neumaticosEnBox;
    private boolean neumaticosMontados;

    public NeumaticosEquipo(String name, int yearf, int trophies, int cantidadNeumaticos) {
        super(name, yearf, trophies);
        this.cantidadNeumaticos = cantidadNeumaticos;
        this.neumaticosEnBox = false;
        this.neumaticosMontados = false;
    }
        
        public int getCantidadNeumaticos() {
            return cantidadNeumaticos;
    }

    public void setCantidadNeumaticos(int cantidadNeumaticos) {
        this.cantidadNeumaticos = cantidadNeumaticos;
    }

    public boolean isNeumaticosEnBox() {
        return neumaticosEnBox;
    }

    public void setNeumaticosEnBox(boolean neumaticosEnBox) {
        this.neumaticosEnBox = neumaticosEnBox;
    }

    public boolean isNeumaticosMontados() {
        return neumaticosMontados;
    }

    public void setNeumaticosMontados(boolean neumaticosMontados) {
        this.neumaticosMontados = neumaticosMontados;
    }
    public void llevarNeumaticosAlBox() {
        if (!neumaticosEnBox) {
            neumaticosEnBox = true;
            System.out.println("Neumáticos llevados al box.");
        } else {
            System.out.println("Los neumáticos ya están en el box.");
        }
    }
    
    public void montarNeumaticosEnCoche() {
        if (neumaticosEnBox && !neumaticosMontados) {
            neumaticosMontados = true;
            System.out.println("Neumáticos montados en el coche.");
        } else if (!neumaticosEnBox) {
            System.out.println("Primero lleva los neumáticos al box.");
        } else {
            System.out.println("Los neumáticos ya están montados en el coche.");
        }
    }
}
