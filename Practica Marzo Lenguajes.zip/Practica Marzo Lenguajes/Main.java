//realizado por diego alejandro jaramillo calderon

class Main{
    
    
public static void main(String[] args){
    F1Team team = new F1Team("AllTeams", 1850, 1000000);
    team.presentarse();
    PitCrewTeam pitCrewTeam = new PitCrewTeam("PitCrew", 2000, 5);
    TeamDriverA teamDriverA = new TeamDriverA("DriverA", 2005, 3, 10);
    TeamDriverB teamDriverB = new TeamDriverB("DriverB", 2010, 7, 8);
    F1Team f1Team = new F1Team("F1Team", 2015, 12);
    //encapsulamiento
    pitCrewTeam.setTrophies(6);
    teamDriverA.setYearf(1932);
    teamDriverB.setYearf(1999);
    f1Team.setTrophies(15);

    PistolaAflojarTuerca Aflojar = new PistolaAflojarTuerca(false, 0, "PitCrew", 2000, 5);
   Aflojar.setEstaEncendida(true);
    Aflojar.aflojarTuerca();
    pitCrewTeam.realizarOperacion();
   
    QuitarLlanta quitarLlanta = new QuitarLlanta(true, 10, "PitCrew", 2000, 5);
    quitarLlanta.setEstaEncendida(false);
    quitarLlanta.encender();
    quitarLlanta.quitarNeumaticos();
    quitarLlanta.apagar();
    pitCrewTeam.realizarOperacion();//polimorfismo, se hace un metodo de forma diferente dependiendo la clase
    
    NeumaticosEquipo neumatico = new NeumaticosEquipo("PitCrew", 2000, 5, 8);
    neumatico.setCantidadNeumaticos(4);
    neumatico.llevarNeumaticosAlBox();
    neumatico.montarNeumaticosEnCoche();
    pitCrewTeam.realizarOperacion();
   
    LevantarAutomovil LevantarAutomovil = new LevantarAutomovil("TeamA", 2000, 5, 4, true, "gato", 0.0);
    LevantarAutomovil.setAutomovilLevantado(false);
    LevantarAutomovil.levantar();
    LevantarAutomovil.levantar();
    teamDriverA.realizarOperacion(); 

    AjustarAleron ajustar = new AjustarAleron("TeamDriverB", 2010, 7, 2, true, "negativo");
    ajustar.setAleronAjustado(false);
    ajustar.setCambioAerodinamico("positivo");
    ajustar.ajustarAleron();
    teamDriverB.realizarOperacion();

    Signal signal = new Signal("TeamA", 2000, 7, 1, true);
    signal.setSignalRight(false);
    signal.darSenalSoltarCoche();
    teamDriverA.realizarOperacion();

} 



}