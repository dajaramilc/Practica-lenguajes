public class QuitarLlanta extends PitCrewTeam {
    
    private boolean estaEncendida;
    private int velocidad;

    public QuitarLlanta(boolean estaEncendida, int velocidad, String name, int yearf, int trophies) {
        super(name, yearf, trophies);
        this.estaEncendida = false;
        this.velocidad = 0;
    }

    public boolean getEstaEncendida() {
        return estaEncendida;
    }
    public void setEstaEncendida(boolean estaEncendida) {
        this.estaEncendida = estaEncendida;
    }

    public int getVelocidad() {
        return velocidad;
    }

    
    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

 
    public void encender() {
        setEstaEncendida(true);
        System.out.println("Herramienta para quitar neumáticos encendida.");
    }

    public void apagar() {
        setEstaEncendida(false);
        System.out.println("Herramienta para quitar neumáticos apagada.");
    }

   

    public void quitarNeumaticos() {
        if (getEstaEncendida()) {
            System.out.println("Quitando los neumáticos a velocidad " + getVelocidad() + "...");
          
        } else {
            System.out.println("Primero encienda la herramienta.");
        }
    }
}
