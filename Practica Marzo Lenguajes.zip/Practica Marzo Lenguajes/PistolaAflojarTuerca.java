public class PistolaAflojarTuerca extends PitCrewTeam {
//herencia, por parte de PitCrewTeam hacia esta clase
    private boolean estaEncendida;
    private int velocidad;

    public PistolaAflojarTuerca(boolean estaEncendida, int velocidad, String name, int yearf, int trophies) {
        super(name, yearf, trophies);
        this.estaEncendida = false;
        this.velocidad = 0;
    }

    public boolean getEstaEncendida() {
        return estaEncendida;
    }

    public void setEstaEncendida(boolean estaEncendida) {
        this.estaEncendida = estaEncendida;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
//abstraccion, se imprime lo necesaio, lo que se pide
    public void encender() {
        setEstaEncendida(true);
        System.out.println("Pistola para aflojar tuercas encendida.");
    }
    public void apagar() {
        setEstaEncendida(false);
        System.out.println("Pistola para aflojar tuercas apagada.");
    }
    public void aflojarTuerca() {
        if (getEstaEncendida()) {
            System.out.println("Aflojando la tuerca a velocidad " + getVelocidad() + "...");
        } else {
            System.out.println("Primero encienda la pistola.");
        }
    }
}
