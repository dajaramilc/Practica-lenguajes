import java.util.Scanner;

class F1Team {
    Scanner scanner = new Scanner(System.in);
    String name;
    int yearf;
    int trophies;
    
    public F1Team(String name, int yearf, int trophies){
        this.name = name;
        this.yearf = yearf;
        this.trophies = trophies;
    }
public String getName() { 
    
return name;
}
public int getYearf() {

    return yearf;
}
public int getTrophies() {
    return trophies;
}
public void setName(String name) {
    this.name = name;
}
public void setYearf(int yearf) {
    this.yearf = yearf;
}
public void setTrophies(int trophies) {
    this.trophies = trophies;
}
public void presentarse(){
    System.out.println("Hola, somos el F1 Team");
}
public void irse(){
    System.out.println("Adios, fue un placer");
}
    
}
