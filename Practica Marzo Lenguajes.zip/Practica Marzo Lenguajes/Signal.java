public class Signal extends TeamDriverA {

   
    private boolean signalright;

 
    public Signal(String name, int yearf, int trophies, int numberMembers,
                               boolean signalright) {
        super(name, yearf, trophies, numberMembers);
        this.signalright = signalright;
    }

    
    public void darSenalSoltarCoche() {
        if (!signalright) {
            signalright = true;
            System.out.println("Dando la señal para que se suelte el coche.");
        } else {
            System.out.println("La señal para soltar el coche ya ha sido dada.");
        }
    }

    public boolean isSignalRight() {
        return signalright;
    }

    public void setSignalRight(boolean signalright) {
        this.signalright = signalright;
    }
}
