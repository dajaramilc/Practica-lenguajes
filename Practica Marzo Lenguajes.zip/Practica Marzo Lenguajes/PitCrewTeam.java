public class PitCrewTeam {
    
    private String name;
    private int yearf;
    private int trophies;
    
    public PitCrewTeam(String name, int yearf, int trophies) {
        this.name = name;
        this.yearf = yearf;
        this.trophies = trophies;
    }

    public String getName() {
        return name;
    }
    
    public int getYearf() {
        return yearf;
    }
    
    public int getTrophies() {
        return trophies;
    }
    
 
    public void setName(String name) {
        this.name = name;
    }
    
    public void setYearf(int yearf) {
        this.yearf = yearf;
    }
    
    public void setTrophies(int trophies) {
        this.trophies = trophies;
    }
    private void realizarAccionPitCrewTeam() {
        System.out.println("Esta acción fue realizada por el integrante del equipo PitCrewTeam: " + getName());
    }
    
    public void realizarOperacion() {
        System.out.println("Realizando operación...");
      
        realizarAccionPitCrewTeam();
    }
}

