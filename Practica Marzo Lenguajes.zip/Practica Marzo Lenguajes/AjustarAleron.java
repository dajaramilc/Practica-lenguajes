public class AjustarAleron extends TeamDriverB {


    private boolean aleronAjustado;
    private String cambioAerodinamico;

    public AjustarAleron(String name, int yearf, int trophies, int numberMembers,
                        boolean aleronAjustado, String cambioAerodinamico) {
        super(name, yearf, trophies, numberMembers);
        this.aleronAjustado = aleronAjustado;
        this.cambioAerodinamico = cambioAerodinamico;
    }
    
    public boolean isAleronAjustado() {
        return aleronAjustado;
    }
    
    public void setAleronAjustado(boolean aleronAjustado) {
        this.aleronAjustado = aleronAjustado;
    }
    
    public String getCambioAerodinamico() {
        return cambioAerodinamico;
    }
    
    public void setCambioAerodinamico(String cambioAerodinamico) {
        this.cambioAerodinamico = cambioAerodinamico;
    }
    
        public void ajustarAleron() {
            if (!aleronAjustado) {
                aleronAjustado = true;
                System.out.println("Ajustando el alerón delantero para aplicar cambios aerodinámicos: " + getCambioAerodinamico());
            } else {
                System.out.println("El alerón delantero ya está ajustado.");
            }
        }
    
        public void restablecerAleron() {
            if (aleronAjustado) {
                aleronAjustado = false;
                System.out.println("Restableciendo el alerón delantero a su posición original.");
            } else {
                System.out.println("El alerón delantero ya está en su posición original.");
            }
        }
}
