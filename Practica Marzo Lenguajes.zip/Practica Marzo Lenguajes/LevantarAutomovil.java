public class LevantarAutomovil extends TeamDriverA {

    private boolean automovilLevantado;
    private String herramientaUtilizada;
    private double alturaLevantada;

    public LevantarAutomovil(String name, int yearf, int trophies, int numberMembers,
                             boolean automovilLevantado, String herramientaUtilizada, double alturaLevantada) {
        super(name, yearf, trophies, numberMembers);
        this.automovilLevantado = automovilLevantado;
        this.herramientaUtilizada = herramientaUtilizada;
        this.alturaLevantada = alturaLevantada;
    }
    
    public boolean isAutomovilLevantado() {
        return automovilLevantado;
    }
    
    public void setAutomovilLevantado(boolean automovilLevantado) {
        this.automovilLevantado = automovilLevantado;
    }

    public String getHerramientaUtilizada() {
        return herramientaUtilizada;
    }

    public void setHerramientaUtilizada(String herramientaUtilizada) {
        this.herramientaUtilizada = herramientaUtilizada;
    }

    public double getAlturaLevantada() {
        return alturaLevantada;
    }

    public void setAlturaLevantada(double alturaLevantada) {
        this.alturaLevantada = alturaLevantada;
    }
    public void levantar() {
        if (!automovilLevantado) {
            automovilLevantado = true;
            System.out.println("Levantando la parte delantera, trasera, y lateral del automóvil en el aire...");
       
        } else {
            System.out.println("El automóvil ya está levantado en el aire.");
        }
    }
    
    public void bajar() {
        if (automovilLevantado) {
            automovilLevantado = false;
            System.out.println("Bajando la parte delantera, delantera, trasera, y lateral del automóvil al suelo...");
        } else {
            System.out.println("El automóvil ya está en el suelo.");
        }
    }
}
